programmer: daniel Yavnilovich

for more details please see project book


first time use run reset_DB.py for DB creation